# Color Processing

This package implements many methods for color fetching aswell as color name and information fetching
This can all be super intensive on memory but this is the best way of managing it from what I can tell
(might change later)
